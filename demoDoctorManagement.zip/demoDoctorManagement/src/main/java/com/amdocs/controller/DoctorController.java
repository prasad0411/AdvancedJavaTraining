package com.amdocs.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amdocs.entity.Doctor;
import com.amdocs.service.DoctorService;

@RestController
@RequestMapping("/api/doctors")
public class DoctorController {

	@Autowired
	private DoctorService doctorService;

	@GetMapping("/getAll")
	public List<Doctor> getAllDoctors() {
		System.out.println("Getting all doctors...");
		List<Doctor> doctors = doctorService.getAllDoctors();
		System.out.println("Total doctors found: " + doctors.size());
		return doctors;
	}

	@GetMapping("/getById/{id}")
	public ResponseEntity<Doctor> getDoctorById(@PathVariable Long id) {
		System.out.println("Getting doctor by ID: " + id);
		Optional<Doctor> doctor = doctorService.getDoctorById(id);
		if (doctor.isPresent()) {
			System.out.println("Doctor found: " + doctor.get());
			return ResponseEntity.ok(doctor.get());
		} else {
			System.out.println("Doctor not found with ID: " + id);
			return ResponseEntity.notFound().build();
		}
	}

	@PostMapping("/addDoc")
	public ResponseEntity<String> createDoctor(@RequestBody Doctor doctor) {
		System.out.println("Creating a new doctor...");
		doctorService.saveDoctor(doctor);
		System.out.println("Doctor created successfully: " + doctor);
		return ResponseEntity.ok("Doctor has been created successfully");
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<String> updateDoctor(@PathVariable Long id, @RequestBody Doctor updatedDoctor) {
		System.out.println("Updating doctor with ID: " + id);
		if (doctorService.getDoctorById(id).isPresent()) {
			updatedDoctor.setId(id);
			doctorService.saveDoctor(updatedDoctor);
			System.out.println("Doctor updated successfully: " + updatedDoctor);
			return ResponseEntity.ok("Doctor has been updated successfully");
		} else {
			System.out.println("Doctor not found with ID: " + id + ". Update failed.");
			return ResponseEntity.notFound().build();
		}
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteDoctor(@PathVariable Long id) {
		System.out.println("Deleting doctor with ID: " + id);
		if (doctorService.getDoctorById(id).isPresent()) {
			doctorService.deleteDoctor(id);
			System.out.println("Doctor deleted successfully with ID: " + id);
			return ResponseEntity.ok("Doctor has been deleted successfully");
		} else {
			System.out.println("Doctor not found with ID: " + id + ". Deletion failed.");
			return ResponseEntity.notFound().build();
		}
	}
}
