package com.amdocs.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.amdocs.entity.Patient;
import com.amdocs.service.PatientService;

@RestController
@RequestMapping("/api/patients")
public class PatientController {

    @Autowired
    private PatientService patientService;

    @GetMapping("/getAll")
    public List<Patient> getAllPatients() {
        System.out.println("Getting all patients...");
        List<Patient> patients = patientService.getAllPatients();
        System.out.println("Total patients found: " + patients.size());
        return patients;
    }

    @GetMapping("/{id}")
    public ResponseEntity<Patient> getPatientById(@PathVariable Long id) {
        System.out.println("Getting patient by ID: " + id);
        Optional<Patient> patient = patientService.getPatientById(id);
        if (patient.isPresent()) {
            System.out.println("Patient found: " + patient.get());
            return ResponseEntity.ok(patient.get());
        } else {
            System.out.println("Patient not found with ID: " + id);
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/addPatient")
    public ResponseEntity<String> createPatient(@RequestBody Patient patient) {
        System.out.println("Creating a new patient...");
        patientService.savePatient(patient);
        System.out.println("Patient created successfully: " + patient);
        return ResponseEntity.ok("Patient has been created successfully");
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updatePatient(@PathVariable Long id, @RequestBody Patient updatedPatient) {
        System.out.println("Updating patient with ID: " + id);
        if (patientService.getPatientById(id).isPresent()) {
            updatedPatient.setId(id);
            patientService.savePatient(updatedPatient);
            System.out.println("Patient updated successfully: " + updatedPatient);
            return ResponseEntity.ok("Patient has been updated successfully");
        } else {
            System.out.println("Patient not found with ID: " + id + ". Update failed.");
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletePatient(@PathVariable Long id) {
        System.out.println("Deleting patient with ID: " + id);
        if (patientService.getPatientById(id).isPresent()) {
            patientService.deletePatient(id);
            System.out.println("Patient deleted successfully with ID: " + id);
            return ResponseEntity.ok("Patient has been deleted successfully");
        } else {
            System.out.println("Patient not found with ID: " + id + ". Deletion failed.");
            return ResponseEntity.notFound().build();
        }
    }
}
